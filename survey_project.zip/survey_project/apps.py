from django.apps import AppConfig


class SurveyProjectConfig(AppConfig):
    name = 'survey_project'
